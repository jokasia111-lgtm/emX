#!/bin/sh
# Inside the PRoot distro, as root: installs RADV-Xclipse as the system's Vulkan driver for the GPU.
set -e
dir="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /usr/lib/xclipse /usr/share/vulkan/icd.d
cp "$dir/libvulkan_radeon.so" /usr/lib/xclipse/
cp "$dir/radeon_icd.aarch64.json" /usr/share/vulkan/icd.d/radeon_xclipse_icd.aarch64.json
echo "installed: /usr/lib/xclipse/libvulkan_radeon.so"
