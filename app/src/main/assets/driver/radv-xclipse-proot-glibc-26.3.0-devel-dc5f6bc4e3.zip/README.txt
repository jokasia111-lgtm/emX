RADV for Samsung Xclipse -- glibc Linux build (Termux PRoot)
=============================================================

The Vulkan driver for the Xclipse 920 (Galaxy S22 series), built for glibc Linux userspaces running
on the phone: Debian, Ubuntu and other distributions under Termux + proot-distro. Same driver as
the Android radv-xclipse package (Mesa 26.3.0-devel with the Xclipse changes), Vulkan 1.4.

Needs: glibc 2.29 or newer (Debian 11+, Ubuntu 20.04+), and libvulkan1 plus the X11/xcb libraries,
which any desktop install already has. The driver opens /dev/dri/renderD128 directly; proot-distro
binds /dev by default.

Install (inside the distribution, as root)
------------------------------------------
    unzip radv-xclipse-proot-glibc-*.zip -d radv-proot
    sh radv-proot/install.sh

This copies the driver to /usr/lib/xclipse/ and its ICD file to
/usr/share/vulkan/icd.d/radeon_xclipse_icd.aarch64.json.

Use
---
Point the Vulkan loader at it (the distribution's own Mesa drivers may be installed too):

    export VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/radeon_xclipse_icd.aarch64.json
    vulkaninfo --summary        # AMD Radeon Graphics (RADV VANGOGHLITE), Mesa 26.3.0-devel

On screen, with Termux:X11 (in Termux: termux-x11 :0 &, then open the Termux:X11 app):

    proot-distro login debian --shared-tmp
    DISPLAY=:0 vkcube

Presentation
------------
- Termux:X11 (DRI3): the GPU renders into a buffer Termux:X11 reads directly. Fastest.
- X servers without DRI3 (VNC and similar): frames are copied by the CPU and sent with PutImage.
  Chosen automatically per window; MESA_VK_WSI_DEBUG=sw forces the CPU copy everywhere.

Diagnostics
-----------
Android property knobs of the Android build are environment variables here: drop "debug.", upper
case, dots as underscores. RADV_XCLIPSE_LOG=1 prints the [BUILD] line and the diagnostic markers to
stderr; RADV_XCLIPSE_LOG=2 adds the verbose trace.

Licenses: see NOTICE.txt. The driver is MIT licensed (Mesa).
